library(shiny)
library(leaflet)
library(data.table)
library(plotly)
library(DT)
library(shinydashboard)
library(leaflet.extras)
library(shinythemes)
library(shinyWidgets)
library(htmltools)

shinyUI(
  fluidPage(includeCSS("style.css"),
            navbarPage(p(class="h","Manhattan Rent"),id = "inTabset",
                       tabPanel("Explorer",fluidPage(
                         fluidRow(
                           tags$div(id="searchBar",
                                    column(width=1,
                                           style = "width:270px;display:inline-block;margin-right: 0px;margin-bottom:0px;margin-top:0px;padding-right:0px",
                                           textInput(inputId="location",label="", value="", placeholder = "search your location...")
                                    ),
                                    column(width=1,
                                           style = "margin-top: 25px;display:inline-block;margin-right: 0px;margin-left: 0px;left:0px;bottom:5px;padding-left:0px",
                                           actionButton("button1",label="", icon = icon("search"))
                                           #,style="padding:12px; font-size:100%;color: #fff; background-color: #337ab7; border-color: #2e6da4")
                                    )),
                           # column(width=1,style = "margin-top: 25px;display:inline-block;margin-right: 0px;",
                           #        actionButton("button2",label="Clear search")
                           #                     #, style="padding:10px; font-size:80%;color: #fff; background-color: #f29898")
                           # ),
                           column(width=1,
                                  style = "margin-top: 25px;display:inline-block;margin-right: 0px;margin-left: 120px",
                                  dropdownButton(circle = FALSE,
                                                 label="Min price",  status = "default",
                                                 numericInput(inputId="min_price", label = "choose",value=0, min=0,max=1000000,step=1000)
                                  )
                                  #selectInput(inputId="min_price",label="", choices = seq(0,10000,50) )
                           ),
                           column(width=1,
                                  style = "margin-top: 25px;display:inline-block;margin-right: 0px;",
                                  dropdownButton(circle = FALSE,
                                                 label="Max price",  status = "default", 
                                                 numericInput(inputId="max_price", value=1000000, label="choose",min=0,max=1000000,step=1000 )
                                  )),
                           column(width=1, 
                                  style="margin-top: 25px;display:inline-block;margin-right: 10px",
                                  dropdownButton(circle = FALSE,
                                                 label = "Bedrooms", status = "default",
                                                 selectInput(inputId="min_bedrooms", label="choose", choices = c("studio"=0,"1b"=1,"2b"=2,"3b"=3,"4b"=4,"5b"=5,"6b"=6)
                                                             
                                                 ))
                                  # selectInput(inputId="min_bedrooms", label="",choices = c("min bedroom"=0,"studio"=1,"1b"=2,"2b"=3,"3b"=4,"4b"=5,"5b"=6,"6b"=7))
                           ),
                           
                           column(width=1,
                                  style = "margin-top: 25px;;display:inline-block;margin-right: 10px;",
                                  dropdownButton(circle = FALSE,
                                                 label = "Bathroom", status = "default",
                                                 selectInput(inputId="min_bathrooms", label="choose", choices = c("studio"=0,"1b"=1,"2b"=2,"3b"=3,"4b"=4,"5b"=5,"6b"=6)
                                                             
                                                 )
                                  )),
                           column(width=1, 
                                  style = "margin-top: 25px;display:inline-block;margin-right: 0px;",
                                  actionButton("button2",label="Reset" 
                                               #,style="padding:12px; font-size:80%;color: #fff; background-color: #337ab7; border-color: #2e6da4"
                                  ))),
                         fluidRow(
                           column(3,
                                  selectInput("check2_re", "Restaurant Type:", c("Food I Like"="",list("American", "Chinese", "Italian", "Japanese", "Pizza", "Others")), multiple=TRUE)),
                           column(3,
                                  selectInput("check2_tr", "Transportation:", list("Who Cares.","Emmm.","It's everything."))),
                           column(3,
                                  selectInput("check2_cb", "Club/Bar:", list("I'm allergic.","Drink one or two.","Let's party!"))),
                           column(3,
                                  
                                  selectInput("check2_ct", "Cinema/Theater:",list("Netflix for life.","It depends.","Theatre goers."))),
                           column(3,
                                  selectInput(inputId = "check2_ma",label = "Market",choices = list("Just Amazon." = 3,"It depends." = 2,"Love it!" =1))               
                                                 )),
                         
                         fluidRow(
                           column(6,
                                  leafletOutput("map", width = "220%", height = 650),
                                  
                                  absolutePanel(id="legend",
                                                fixed = TRUE,
                                                draggable = TRUE, top = 140, left = "auto", right = 80, bottom = "auto",
                                                width = 125, height = 215,
                                                checkboxInput("Crime", label = "Crime",value= FALSE),
                                                checkboxInput("Bus", label = "Bus",value= FALSE),
                                                checkboxInput("Subway",label="Subway",value = FALSE),
                                                checkboxInput("Market", label = "Market",value = FALSE),
                                                checkboxInput("Restaurant", label = "Restaurant",value= FALSE)                               
                                                
                                                )
                                                
                                                # checkboxInput("Restaurant", label = "Restaurant",value= FALSE))),                                 
                                                # 
                                                # column(6,
                                                #        dataTableOutput("recom")
                                                # )
                         )
                         ),
                      fluidRow(column(6,
                                      dataTableOutput("recom")
                      ))
                       )
                       )
            )))