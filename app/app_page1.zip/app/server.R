library(ggmap)
library(ggplot2)
library(dplyr)
library(DT)

setwd("/Users/claudia/Desktop/app")
rank_all <- read.csv("./data/house_rank_all.csv", as.is = T)
show <- read.csv("./data/house_show.csv",as.is = T)
source("./lib/showPopupHover.R")
source("./lib/ZillowApi.R")

shinyServer(function(input, output,session) {
  
  ##########################################################################
  ## Page 1: recommand #####################################################
  ########################################################################## 
  
  #############Map#############
  load("/Users/claudia/Desktop/Fall2017-project2-grp6-master/output/housing.RData") 
  output$map <- renderLeaflet({
    leaflet() %>%
      addProviderTiles('Esri.WorldTopoMap') %>%
      setView(lng = -73.971035, lat = 40.775659, zoom = 12) %>%
      addMarkers(data=housing,
                 lng=~lng,
                 lat=~lat,
                 clusterOptions=markerClusterOptions(),
                 group="housing_cluster"
      )
  })
  # filter housing data:
  
  housingFilter=reactive({
    bedroom_filter=rank_all$bedrooms>=input$min_bedrooms 
    bathroom_filter=rank_all$bathrooms>=input$min_bathrooms
    price_filter=rank_all$price>=input$min_price & rank_all$price<=input$max_price
    # market.fil <- if(input$check2_ma == "Love it!"){
    #   1:16
    # } else if(input$check2_ma == "It depends."){
    #   1:32
    # } else {
    #   c(1:46, NA)
    # }
    market.fil <- if(input$check2_ma == 1){
      1:16
    } else if(input$check2_ma == 2){
      1:32
    } else {
      c(1:46, NA)
    }
#    ranks = read.csv("./data/rank_all.csv", as.is = T)
    market_logi = sapply(rank_all$ranking.market, function(num) num %in% market.fil)

    
    filter=bedroom_filter & bathroom_filter & price_filter & market_logi
    
    return(rank_all[filter,])
  })
  
  # show data in the map:
  observe({leafletProxy("map")%>%clearGroup("housing_cluster")%>%
      addMarkers(data=housingFilter(),
                 lng=~lng,
                 lat=~lat,
                 clusterOptions=markerClusterOptions(),
                 group="housing_cluster"
      )
  })
  # show current status of icons:
  
  showStatus=reactive({
    if (is.null(input$map_bounds)){
      return("cloud")
      
    }
    else{
      if(input$map_zoom<16){
        return('cloud')
      }
      else{
        return('details')
      }
    }
  })
  # hide and show clouds 
  observe({
    if(showStatus()=="cloud"){
      
      leafletProxy("map") %>%showGroup("housing_cluster")%>%clearGroup("new_added")
    }
    else{
      leafletProxy("map") %>%hideGroup("housing_cluster")
      
    }
  })
  
  # show housing details when zoom to one specific level
  
  observe({
    if(showStatus()=="details"){
      if(nrow(marksInBounds())!=0){
        leafletProxy("map")%>%clearGroup(group="new_added")%>% 
          addCircleMarkers(data=marksInBounds(),
                           lat=~lat,
                           lng=~lng,
                           label=~as.character(price),
                           radius=5,
                           stroke=FALSE,
                           fillColor = "blue",
                           fillOpacity=0.5,
                           group="new_added",
                           labelOptions = labelOptions(
                             noHide = T,
                             offset=c(20,-15),
                             opacity=0.7,
                             direction="left",
                             style=list(
                               background="green",
                               color="white"  
                             )
                           )
          )
      }
      else{
        leafletProxy("map")%>%clearGroup(group="new_added")
      }
      
      
      
      
    }
    
    
    
    
  })
  
  # get the housing data in the bounds
  marksInBounds <- reactive({
    if (is.null(input$map_bounds))
      return(rank_all[FALSE,])
    bounds <- input$map_bounds
    latRng <- range(bounds$north, bounds$south)
    lngRng <- range(bounds$east, bounds$west)
    
    return(
      subset(housingFilter(),
             lat>= latRng[1] & lat <= latRng[2] &
               lng >= lngRng[1] & lng <= lngRng[2])
    )
  })
  
  # sort housing in current zoom level
  
  observe({
    
    housing_sort=marksInBounds()
    
    if(nrow(housing_sort)!=0){
      
      action=apply(housing_sort,1,function(r){
        addr=r["addr"]
        lat=r["lat"]
        lng=r["lng"]
        paste0("<a class='go-map' href='' data-lat='",lat,"'data-lng='",lng,"'>",addr,'</a>')   
      }
      )
      
      housing_sort$addr=action
      output$rank <- renderDataTable(housing_sort[,c("addr","price","bedrooms","bathrooms")],escape=FALSE)
      
      
      
      
    }
    else{
      
      output$rank=renderDataTable(housing_sort[,c("addr","price","bedrooms","bathrooms")])
    }
    
  })
  
  # When point in map is hovered, show a popup with housing info
  observe({
    
    event <- input$map_marker_mouseover
    if (is.null(event))
      return()
    if(showStatus()=="details"){
      isolate({
        showPopupHover(event$lat, event$lng,housing=housingFilter())
      })  
    }
    
  })
  
  # mouseout the point and cancel popup
  observe({
    
    event <- input$map_marker_mouseout
    if (is.null(event))
      return()
    
    isolate({
      leafletProxy("map") %>% clearPopups()
    })
  })
  
  # click name to go to that point
  observe({
    if (is.null(input$goto))
      return()
    isolate({
      map <- leafletProxy("map")
      
      
      
      lat <- as.numeric(input$goto$lat)
      lng <- as.numeric(input$goto$lng)
      
      map %>% setView(lng = lng, lat = lat, zoom = 16)
    })
  })
  # hover the list to show info
  observe({
    if (is.null(input$showPop))
      return()
    isolate({
      remove=as.numeric(input$showPop$remove)
      map <- leafletProxy("map")
      
      if(remove==0){
        
        
        
        lat <- as.numeric(input$showPop$lat)
        lng <- as.numeric(input$showPop$lng)
        showPopupHover(lat, lng,housingFilter())   
      }
      else{
        map %>% clearPopups()
      }
      
      
    })
  })
  
  #############Search###############
  observeEvent(input$button1,{
    url = paste0('http://maps.google.com/maps/api/geocode/xml?address=',input$location,'&sensor=false')
    doc = xmlTreeParse(url) 
    root = xmlRoot(doc) 
    lati = as.numeric(xmlValue(root[['result']][['geometry']][['location']][['lat']])) 
    long = as.numeric(xmlValue(root[['result']][['geometry']][['location']][['lng']]))
    
    leafletProxy("map") %>%
      setView(lng=long, lat=lati,zoom=15)%>%
      addMarkers(lng=long,lat=lati,layerId = "1",icon=icons(
        iconUrl = "../output/icons8-Location-50.png",iconWidth = 25, iconHeight = 25))
  })
  #################Clear Choices############
  observeEvent(input$button2,{
    proxy<-leafletProxy("map")
    proxy %>%
      setView(lng = -73.971035, lat = 40.775659, zoom = 12) %>%
      removeMarker(layerId="1") %>%
      addMarkers(data=rank_all,
                 lng=~lng,
                 lat=~lat,
                 clusterOptions=markerClusterOptions(),
                 group="housing_cluster")
    updateTextInput(session, inputId="location", value = "")
  }
  
  )
  
  
  ##Clear
  observeEvent(input$no_rec2, {
    updateSliderInput(session, "check2_pr",value = 5400)
    updateSelectInput(session, "check2_ty",selected="")
    updateSelectInput(session, "check2_re",selected="")
    updateSelectInput(session, "check2_tr",selected = "Who Cares.")
    updateSelectInput(session, "check2_cb",selected = "I'm allergic.")
    updateSelectInput(session, "check2_ct",selected = "Netflix for life.")
    updateSelectInput(session, "check2_ma",selected = "Just Amazon.")
  })
  
  
  
  ##Recommand
  areas  <- reactive({
    cond.ame <- if(is.null(input$check2_re)){"ranking.American <= 46 |is.na(ranking.American) == TRUE"
    } else if("American" %in% input$check2_re){"ranking.American <= 23"
    } else {"ranking.American <= 46 |is.na(ranking.American) == TRUE"}
    
    cond.chi <- if(is.null(input$check2_re)){"ranking.Chinese <= 46 |is.na(ranking.Chinese) == TRUE"
    } else if("Chinese" %in% input$check2_re) {"ranking.Chinese <= 23"
    } else {"ranking.Chinese <= 46 |is.na(ranking.Chinese) == TRUE"}
    
    cond.ita <-  if(is.null(input$check2_re)){"ranking.Italian <= 46 |is.na(ranking.Italian) == TRUE"
    } else if("Italian" %in% input$check2_re) {"ranking.Italian <= 23"
    } else {"ranking.Italian <= 46 |is.na(ranking.Italian) == TRUE"}
    
    cond.jap <- if(is.null(input$check2_re)){"ranking.Japenses <= 46 |is.na(ranking.Japenses) == TRUE"
    } else if("Japanese" %in% input$check2_re) {"ranking.Japenses <= 23"
    } else {"ranking.Japenses <= 46 |is.na(ranking.Japenses) == TRUE"}
    
    cond.piz <- if(is.null(input$check2_re)){"ranking.Pizza <= 46 |is.na(ranking.Pizza) == TRUE"
    } else if("Pizza" %in% input$check2_re) {"ranking.Pizza <= 23"
    } else {"ranking.Pizza <= 46 |is.na(ranking.Pizza) == TRUE"}
    
    cond.oth <- if(is.null(input$check2_re)){"ranking.Others <= 46 |is.na(ranking.Others) == TRUE"
    } else if("Others" %in% input$check2_re) {"ranking.Others <= 23"
    } else {"ranking.Others <= 46 |is.na(ranking.Others) == TRUE"}
    
    trans.fil <- if(input$check2_tr == "It's everything."){
      1:16
    } else if(input$check2_tr == "Emmm."){
      1:32
    } else {
      c(1:46, NA)
    }
    
    club.fil <- if(input$check2_cb == "Let's party!"){1:16
    } else if(input$check2_cb == "Drink one or two."){
      1:32
    } else {
      c(1:46, NA)
    }
    
    theatre.fil<- if(input$check2_ct == "Theatre goers."){1:16
    } else if(input$check2_ct == "It depends."){
      1:32
    } else {
      c(1:46, NA)
    }
    
    market.fil <- if(input$check2_ma == "Love it!"){
      1:16
    } else if(input$check2_ma == "It depends."){
      1:32
    } else {
      c(1:46, NA)
    }
    ranks = read.csv("./data/rank_all.csv", as.is = T)
    logi = sapply(ranks$ranking.market, function(num) num %in% market.fill)
    chosen_zip = ranks[logi,"zipcode"]
    return(chosen_zip)
    # areas <- (housingFilter() %>%
    #             filter(eval(parse(text = cond.ame)), eval(parse(text = cond.chi)), eval(parse(text = cond.ita)),
    #                    eval(parse(text = cond.jap)), eval(parse(text = cond.piz)), eval(parse(text = cond.oth)),
    #                    ranking.trans %in% trans.fil, ranking.bar %in% club.fil,
    #                    ranking.theatre %in% theatre.fil, ranking.market %in% market.fil
    #             ) %>%
    #             select(zipcode))[,1]
    # return(areas)
  })
  # output$recom <- renderDataTable(housingFilter(),
  #                                 options = list("sScrollX" = "100%", "bLengthChange" = FALSE)) 
  
  output$recom <- renderDataTable(show %>%
                                    filter(
  zipcode %in% housingFilter()$zipcode
                                      # zipcode %in% areas()
                                    ),
                                  options = list("sScrollX" = "100%", "bLengthChange" = FALSE))

  
})